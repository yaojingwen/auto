create procedure PROC_BATCH_BALANCE_ADD
IS
  V_SQL          varchar2(10000);
  format_sysdate varchar2(14);
  source_id_so   varchar(20);
  source_id_ams  varchar(20);
  dblk_crm       varchar(20);
  dblk_ams       varchar(20);
  N_COUNTY_CODE  number(8);
  N_ACCT_ID      number(20);
  N_SERV_ID      number(20);
  N_CUST_ID      number(20);

begin
  select to_char(sysdate,'yyyymmddhh24miss') Into format_sysdate from dual;

begin
  for rec in
   (select t.rowid,t.* from cvt.sf_target_user t where flag=0)
loop

if rec.region_id in (790,791,792,793,794) then
source_id_so:='so1';
source_id_ams:='ams1';
dblk_crm:='@dblk_to_crmdba1';

else
source_id_so:='so2';
source_id_ams:='ams2';
dblk_crm:='@dblk_to_crmdbb1';
dblk_ams:='@dblk_to_bossdbb1';
end if;

---获取用户的user_id
V_SQL:='select user_id,cust_id,country_code from '||source_id_so||'.ins_user_'||rec.region_id||''||dblk_crm||' where bill_id='''||rec.phone_id||''' ';
execute immediate V_SQL into N_SERV_ID,N_CUST_ID,N_COUNTY_CODE ;

---获取用户的实际账户ID
V_SQL:='select acct_id from '||source_id_so||'.ins_accrel_'||rec.region_id||''||dblk_crm||' where user_id='||N_SERV_ID||' '||
       ' and pay_type=1 and expire_date>sysdate';
execute immediate V_SQL into N_ACCT_ID ;


V_SQL:='insert into '||source_id_ams||'.AM_PS_PAYMENT_BAT_'||rec.region_id||'
  (PAYMENT_ID,
  OPT_SEQ,
  PEER_SEQ,
  PEER_DATE,
  BUSINESS_ID,
  OPERATION_TYPE,
  ACCT_ID,
  ACCT_TYPE,
  ORIG_PAYMENT_ID,
  PAYED_TYPE,
  AMOUNT,
  BALANCE_TYPE_ID,
  SPE_PAY_TYPE,
  SPE_PAY_ID,
  EFFECTIVE_DATE,
  EXPIRE_DATE,
  CERTIFICATE_TYPE,
  CERTIFICATE_CODE,
  USER_ID,
  BILL_ID,
  BRAND_ID,
  OPT_DATE,
  PROCESS_ID,
  ACTION,
  CTRL_FLAG,
  CREATE_DATE,
  PROCESS_STATUS,
  PROCESS_DATE,
  BALANCE,
  OP_ID,
  ORG_ID,
  REGION_ID,
  COUNTY_CODE,
  ACCT_COUNTY_CODE,
  OPT_REGION_ID,
  BILLING_CYCLE_ID,
  CUST_ID,
  OFFER_ID,
  REMARKS,
  PROC_PARAM,
  IS_SMS,
  BIG_ACCT_FLAG,
  BILL_DAY,
  PAY_METHOD,
  ERR_MSG,
  ORDER_CODE,
  TYPE_FLAG,
  PAY_DOC_TYPE,
  BAL_INCOME_FLAG,
  JOIN_CHANNEL_ID,
  INIT_CHANNEL_ID,
  IS_AVAILDAY,
  JOIN_CHANNEL_TYPE,
  PAYMENT_METHOD,
  TRADE_ORIGIN)
SELECT   '''||format_sysdate || 'A'' || LPAD(ROWNUM, 8, 0) || substr('||rec.region_id||', 2, 2),
         10000,
          '''||format_sysdate || 'A'' || LPAD(ROWNUM, 8, 0) || substr('||rec.region_id||', 2, 2),
         NULL,
         121000000079,
         ''3'',
         '||N_ACCT_ID||',
         ''1'',
         NULL,
         ''0'',
         a.fee,
         a.BALANCE_TYPE_ID,
         ''0'',
         NULL,
         SYSDATE,
         to_date(''20991231235959'',''YYYYMMDDHH24MISS''),
         ''Z'',
         NULL,
         '||N_SERV_ID||',
         '||REC.PHONE_ID||',
         0,
         SYSDATE,
         ''1'',
         ''1'',
         ''0'',
         SYSDATE,
         ''0'',
         NULL,
         '||REC.AMOUNT||',
         0,  ---送费工号
         0,  ---送费工号组织
         '||REC.REGION_ID||',
         9109,  ---送费区县
         '||N_COUNTY_CODE||',
         '||REC.REGION_ID||',
         to_number(to_char(sysdate,''YYYYMM'')),
         0,
         NULL,
         '||REC.REMARK||',
         ''IS_PRE_PAY=N;IS_BATCH=Y'',
         ''N'',
         ''N'',
         1,
         0,
         NULL,
         NULL,
         NULL,
         ''1'',
         NULL,
         NULL,
         NULL,
         NULL,
         ''6'',
         0,
         NULL
    FROM dual';
execute immediate V_SQL;

V_SQL:='update ams1.sf_target_user set flag=1 where rowid='''||rec.rowid||''' ';
execute immediate V_SQL;

  commit;
end loop;
end;
end;
/

