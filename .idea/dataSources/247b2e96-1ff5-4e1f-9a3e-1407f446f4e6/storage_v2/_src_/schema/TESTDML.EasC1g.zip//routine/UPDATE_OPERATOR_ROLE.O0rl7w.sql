create PROCEDURE UPDATE_OPERATOR_ROLE IS
  V_SQL_UPDATE           VARCHAR2(1000);
  V_SQL_INSERT           VARCHAR2(1000);
  TYPE R_TYPE IS RECORD(
  V_OBJ_ID TESTDML.GEJIEGONGHAO1.OBJ_ID%TYPE,
  V_ROLE_ID TESTDML.GEJIEGONGHAO1.ROLE_ID%TYPE
  );
  V_R1            R_TYPE;
  CURSOR C_TABLE IS

       SELECT T.OBJ_ID,T.ROLE_ID FROM TESTDML.GEJIEGONGHAO1 T;
     BEGIN

       OPEN C_TABLE;--必须要明确的打开和关闭游标
         LOOP
             FETCH C_TABLE INTO V_R1;

      V_SQL_UPDATE  :='UPDATE SEC.SEC_AUTHOR A' || CHR(10) ||
      '   SET A.STATE = ''0'', A.NOTES = ''20181210角色失效@PENGZP''' || CHR(10) ||
      ' WHERE A.AUTHOR_ENTITY_ID IN' || CHR(10) ||
      '       (SELECT T.AUTHOR_ENTITY_ID' || CHR(10) ||
      '          FROM SEC.SEC_AUTHOR_ENTITY T' || CHR(10) ||
      '         WHERE T.OBJ_ID IN ('||V_R1.V_OBJ_ID||')) --T.OBJ_ID  IN(SELECT OP_ID,ROLE_ID FROM TMP_OP_ROLE) 将提供的工号和角色导入到这个临时表呀' || CHR(10) ||
      '   AND A.STATE = 1' || CHR(10) ||
      '   AND A.ROLE_ID NOT IN' || CHR(10) ||
      '       (SELECT ROLE_ID' || CHR(10) ||
      '          FROM SEC.SEC_ROLE B' || CHR(10) ||
      '         WHERE B.ROLE_TYPE = 6 --TO MATCH THE PRIVATE ROLE' || CHR(10) ||
      '           AND B.ROLE_ID <> 99999' || CHR(10) ||
      '           AND B.ROLE_ID IN (SELECT ROLE_ID' || CHR(10) ||
      '                             FROM SEC.SEC_AUTHOR' || CHR(10) ||
      '                            WHERE AUTHOR_ENTITY_ID IN' || CHR(10) ||
      '                                  (SELECT AUTHOR_ENTITY_ID' || CHR(10) ||
      '                                     FROM SEC.SEC_AUTHOR_ENTITY' || CHR(10) ||
      '                                    WHERE OBJ_ID IN ('||V_R1.V_OBJ_ID||'))))';
      EXECUTE IMMEDIATE V_SQL_UPDATE;

      V_SQL_INSERT  :='INSERT INTO SEC.SEC_AUTHOR' || chr(10) ||
      '  SELECT SEC.SEC_AUTHOR$SEQ.NEXTVAL AUTHOR_ID,' || chr(10) ||
      '         B.AUTHOR_ENTITY_ID AUTHOR_ENTITY_ID,' || chr(10) ||
      '         A.ROLE_ID ROLE_ID,' || chr(10) ||
      '         ''C'' AUTHOR_TYPE,' || chr(10) ||
      '         ''0'' PARENT_ROLE_AUTHOR_ID,' || chr(10) ||
      '         A.VALID_DATE AUTHOR_VALID_DATE,' || chr(10) ||
      '         TO_DATE(''20990101'', ''YYYYMMDD'') AUTHOR_EXPIRE_DATE,' || chr(10) ||
      '         ''新岗位@PENGZP'' NOTES,' || chr(10) ||






      '         ''1'' STATE,' || chr(10) ||
      '         ''0'' DONE_CODE,' || chr(10) ||
      '         SYSDATE,' || chr(10) ||
      '         SYSDATE,' || chr(10) ||
      '         SYSDATE,' || chr(10) ||
      '         TO_DATE(''20990101'', ''YYYYMMDD'') EXPIRE_DATE,' || chr(10) ||
      '         0 OP_ID,' || chr(10) ||
      '         0 ORG_ID' || chr(10) ||
      '    FROM SEC.SEC_ROLE A, SEC.SEC_AUTHOR_ENTITY B' || chr(10) ||
      '   WHERE B.OBJ_ID IN ('||V_R1.V_OBJ_ID||') ---工号' || chr(10) ||
      '     AND A.ROLE_ID IN ('||V_R1.V_ROLE_ID||') ----赋予角色' || chr(10) ||
      '     AND NOT EXISTS (SELECT 1' || chr(10) ||
      '            FROM SEC.SEC_AUTHOR C' || chr(10) ||
      '           WHERE B.AUTHOR_ENTITY_ID = C.AUTHOR_ENTITY_ID' || chr(10) ||
      '             AND A.ROLE_ID = C.ROLE_ID)' || chr(10) ||
      '     AND B.OBJ_TYPE = ''OPERATOR''';
      EXECUTE IMMEDIATE V_SQL_INSERT;
commit;

     END LOOP;
    CLOSE C_TABLE;
    END;
/

